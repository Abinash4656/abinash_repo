package com.test.library.demolibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoLibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
