package com.test.library.demolibrary.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.test.library.demolibrary.bookservice.BookService;
import com.test.library.demolibrary.exception.BookNotFoundException;
import com.test.library.demolibrary.exception.LibraryNotFoundException;
import com.test.library.demolibrary.model.BookRequest;
import com.test.library.demolibrary.model.Books;

/*
 * After creating library create book inside library
 * this class contain different resources to perform read, write,update operations
 * on book table
 * */

@RestController
@RequestMapping("/books")
public class BookController {
	@Autowired
	BookService bookService;
   /*
    * Below resource to get book by book id
    * */
	@RequestMapping(value = "/getbook/{bookId}", method = RequestMethod.GET)
	public ResponseEntity<Object> getBookById(@PathVariable("bookId") Integer bookId) {
		try {
			Books bookById = bookService.getBookById(bookId);
			return new ResponseEntity<>(bookById, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>("book not found", HttpStatus.OK);
		}

	}
	/*
	    * Below resource to get book by library id
	    * */
	@RequestMapping(value = "/getbookbylibid/{libraryId}", method = RequestMethod.GET)
	public ResponseEntity<Object> getBookByLibraryId(@PathVariable("libraryId") Integer libraryId) {
		try {
			Books bookById = bookService.getBookByLibraryId(libraryId);
			return new ResponseEntity<>(bookById, HttpStatus.OK);
		} catch (BookNotFoundException e) {
			return new ResponseEntity<>("book not found for library Id: "+libraryId, HttpStatus.OK);
		} catch (LibraryNotFoundException e) {
			return new ResponseEntity<>("invalid library id", HttpStatus.BAD_REQUEST);
		}


	}
	/*
	    * Below resource to create book inside book table
	    * */
	@RequestMapping(value = "/savebook", method = RequestMethod.PUT)
	public ResponseEntity<Object> saveBooks(@RequestBody(required = true) BookRequest books) {

		Boolean savestatus = bookService.saveBook(books);
		if (savestatus) {
			return new ResponseEntity<>("sucsessful", HttpStatus.OK);
		} else {
			return new ResponseEntity<>("couldn't save the book", HttpStatus.BAD_REQUEST);

		}

	}
	
	/*
	    * Below resource to update book info inside book table
	    * */
	@RequestMapping(value = "/updatebook", method = RequestMethod.POST)
	public ResponseEntity<Object> updateBooks(@RequestBody(required = true) Books books) {

		Boolean savestatus = bookService.updateBook(books);
		if (savestatus) {
			return new ResponseEntity<>("sucsessful", HttpStatus.OK);
		} else {
			return new ResponseEntity<>("couldn't save the book", HttpStatus.BAD_REQUEST);

		}

	}
}
