package com.test.library.demolibrary.entities;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Library {
@Id	
public int libraryId;
public int bookId;


public Library() {
	
}
public Library(int libraryId, int bookId) {
	super();
	this.libraryId = libraryId;
	this.bookId = bookId;
}
public int getLibraryId() {
	return libraryId;
}
public void setLibraryId(int libraryId) {
	this.libraryId = libraryId;
}
public int getBookId() {
	return bookId;
}
public void setBookId(int bookId) {
	this.bookId = bookId;
}


}
