package com.test.library.demolibrary.exception;

public class LibraryNotFoundException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
