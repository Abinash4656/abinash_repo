package com.test.library.demolibrary.model;

public class BookRequest extends Books{
	
	private int libraryId;
	public int getLibraryId() {
		return libraryId;
	}
	public void setLibraryId(int libraryId) {
		this.libraryId = libraryId;
	}
}
