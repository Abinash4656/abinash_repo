package com.test.library.demolibrary.bookservice;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.library.demolibrary.DAO.BookRepo;
import com.test.library.demolibrary.DAO.LibraryRepo;
import com.test.library.demolibrary.entities.Book;
import com.test.library.demolibrary.entities.Library;
import com.test.library.demolibrary.exception.BookNotFoundException;
import com.test.library.demolibrary.exception.LibraryNotFoundException;
import com.test.library.demolibrary.model.BookRequest;
import com.test.library.demolibrary.model.Books;

/*
 * service implementation where all h2 data base transactions are happening
 * 
 * 
 * */
@Service
public class BookServiceImpl implements BookService{
	@Autowired
	BookRepo bookRepo;
	@Autowired
	LibraryRepo libraryRepo;
	@Override
	public Books getBookById(Integer bookId) throws BookNotFoundException {
		Optional<Book> BookById = bookRepo.findById(bookId);
		Books books = null;
		if(BookById.isPresent()) {
			Book book = BookById.get();
			System.out.println(book.getBookId());
			books = new Books(book.getBookId(),book.getBookName(),book.getAuthor());
		} else {
			throw new BookNotFoundException();
		}
		return books;
	}
	@Override
	public Boolean saveBook(BookRequest books) {
		Book book = null;
		Library library = null;
		if(null != books) {
			book = new Book(books.getBookId(),books.getBookName(),books.getAuthor());
			library = new Library(books.getLibraryId(),books.getBookId());
		}
		try {
			bookRepo.save(book);
			libraryRepo.save(library);
			return true;
		} catch (Exception e) {
			return false;
		}
		
	}
	@Override
	public Boolean updateBook(Books books) {
		boolean updateStatus = false;
		try {
		boolean existsById = bookRepo.existsById(books.getBookId());
		if(existsById) {
			 bookRepo.deleteById(books.getBookId());
			 Book book = new Book(books.getBookId(),books.getBookName(),books.getAuthor());
			 bookRepo.save(book);
			 updateStatus = true;
		}
		return updateStatus;
		}catch (Exception e) {
			return updateStatus;
		}
	}
	@Override
	public Books getBookByLibraryId(Integer libraryId) throws BookNotFoundException,LibraryNotFoundException {
		Optional<Library> LibraryById = libraryRepo.findById(libraryId);
		int bookId = 0;
		if(LibraryById.isPresent()) {
			Library library = LibraryById.get();
			bookId = library.getBookId();
			if(bookId == 0) {
				throw new BookNotFoundException();
			}
		}else {
			throw new LibraryNotFoundException();
		}
		Books books = null;
		Optional<Book> BookById = bookRepo.findById(bookId);
		if(BookById.isPresent()) {
			Book book = BookById.get();
			System.out.println(book.getBookId());
			books = new Books(book.getBookId(),book.getBookName(),book.getAuthor());
		} else {
			throw new BookNotFoundException();
		}
		return books;
	}

}
