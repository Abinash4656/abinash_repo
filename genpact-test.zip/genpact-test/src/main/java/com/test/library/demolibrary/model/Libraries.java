package com.test.library.demolibrary.model;

public class Libraries {
	public int libraryId;
	public int bookId;
	public Libraries(int libraryId, int bookId) {
		super();
		this.libraryId = libraryId;
		this.bookId = bookId;
	}
	public Libraries() {
		
	}
	public int getLibraryId() {
		return libraryId;
	}
	public void setLibraryId(int libraryId) {
		this.libraryId = libraryId;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	
	
}
