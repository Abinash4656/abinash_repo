package com.test.library.demolibrary.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.test.library.demolibrary.libraryservice.LibraryService;
import com.test.library.demolibrary.model.Libraries;


/*
 * Controller class to create library. To create a Book
 * first create a library with empty book, that means book id is 0
 * 
 * */


@RestController
@RequestMapping("/library")
public class LibraryController {
	@Autowired
	LibraryService libraryService;
	/*
	 * Library request object is the request body to create library first
	 * */
	@RequestMapping(value = "/createLibrary", method = RequestMethod.PUT)
	public ResponseEntity<Object> saveBooks(@RequestBody(required = true) Libraries libraries) {

		Boolean savestatus = libraryService.createLibrary(libraries);
		if (savestatus) {
			return new ResponseEntity<>("sucsessful", HttpStatus.OK);
		} else {
			return new ResponseEntity<>("couldn't create library", HttpStatus.BAD_REQUEST);

		}

	}

}
