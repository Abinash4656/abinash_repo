package com.test.library.demolibrary.libraryservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.library.demolibrary.DAO.LibraryRepo;
import com.test.library.demolibrary.entities.Library;
import com.test.library.demolibrary.model.Libraries;

@Service
public class LibraryServiceImpl implements LibraryService {
	@Autowired
	LibraryRepo libraryRepo;

	@Override
	public boolean createLibrary(Libraries libraries) {
		boolean saveStatus = false;
		try {
			Library library = null;
			if (null != libraries) {
				library = new Library(libraries.getLibraryId(), libraries.getBookId());
			}
			libraryRepo.save(library);
			saveStatus = true;
			return saveStatus;
		} catch (Exception e) {
			return saveStatus;
		}

	}

}
