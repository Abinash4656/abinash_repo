package com.test.library.demolibrary.libraryservice;

import com.test.library.demolibrary.model.Libraries;

public interface LibraryService {
public boolean createLibrary(Libraries libraries);
}
