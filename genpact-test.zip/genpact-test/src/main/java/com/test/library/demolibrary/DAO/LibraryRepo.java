package com.test.library.demolibrary.DAO;

import org.springframework.data.repository.CrudRepository;

import com.test.library.demolibrary.entities.Library;

public interface LibraryRepo extends CrudRepository<Library, Integer> {

}
