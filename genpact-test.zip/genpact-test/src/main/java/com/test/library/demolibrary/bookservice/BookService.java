package com.test.library.demolibrary.bookservice;


import com.test.library.demolibrary.exception.BookNotFoundException;
import com.test.library.demolibrary.exception.LibraryNotFoundException;
import com.test.library.demolibrary.model.BookRequest;
import com.test.library.demolibrary.model.Books;

/*
 * Business services implementation for book module
 * */
public interface BookService {
 public Books getBookById(Integer bookId) throws BookNotFoundException;
 public Books getBookByLibraryId(Integer libraryId) throws BookNotFoundException,LibraryNotFoundException;
 public Boolean saveBook(BookRequest books);
 public Boolean updateBook(Books books);
}
